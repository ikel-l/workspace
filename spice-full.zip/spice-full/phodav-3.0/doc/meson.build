if build_machine.system() == 'windows'
  message('Disabling gtk-doc while building on Windows')
else
  if find_program(
    'gtkdoc-scan',
    required : get_option('gtk_doc'),
  ).found()
    subdir('reference')
  else
    message('Not building documentation as gtk-doc was not found')
  endif
endif

asciidoc = find_program('asciidoc', required : false)
xmlto = find_program('xmlto', required : false)
sed = find_program('sed', required : false)

if asciidoc.found() and xmlto.found() and sed.found()
  gorizont_chezdav_txt = custom_target(
    'gorizont-chezdav source',
    input : 'chezdav.txt',
    output : 'gorizont-chezdav.txt',
    command : [
      sed,
      [
        '-e', 's/^chezdav(1)$/gorizont-chezdav(1)/',
        '-e', 's/^chezdav - /gorizont-chezdav - /',
        '-e', 's/\\*chezdav\\*/\\*gorizont-chezdav\\*/g',
        '-e', 's/The chezdav(1) command/The gorizont-chezdav(1) command/g',
      ],
      '@INPUT@',
    ],
    capture : true,
  )

  xml = custom_target(
    'gorizont-chezdav XML',
    input : gorizont_chezdav_txt,
    output : 'gorizont-chezdav.xml',
    command : [
      asciidoc,
      '-o',
      '@OUTPUT@',
      '--backend=docbook',
      '--doctype=manpage',
      '@INPUT@',
    ],
  )

  custom_target(
    'gorizont-chezdav MAN',
    input : xml,
    output : 'gorizont-chezdav.1',
    command : [
      xmlto,
      'man',
      '-o',
      meson.current_build_dir(),
      '@INPUT@',
    ],
    install : true,
    install_dir : '@0@/man1'.format(mandir),
  )
endif
