/*
 * Copyright (C) 2013 Red Hat, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */

#include "phodav-priv.h"
#include "phodav-utils.h"

typedef struct
{
  GFileOutputStream *output;
  GFile             *file;
  PathHandler       *handler;
  guint64            max_file_size;
  guint64            max_total_size;
  guint64            total_before;
  guint64            old_file_size;
  guint64            received;
  gboolean           too_large;
  gboolean           total_too_large;
} PutState;

static void
method_put_finished (SoupServerMessage *msg,
                     gpointer           user_data)
{
  PutState *state = user_data;

  g_debug ("PUT finished %p", state->output);

  if (state->too_large || state->total_too_large)
    {
      /* Do not leave a partial oversized file in the shared directory. */
      g_output_stream_close (G_OUTPUT_STREAM (state->output), NULL, NULL);
      g_file_delete (state->file, NULL, NULL);
    }

  g_clear_object (&state->output);
  g_clear_object (&state->file);
  g_free (state);
}

static void
method_put_got_chunk (SoupServerMessage *msg,
                      GBytes            *chunk,
                      gpointer           user_data)
{
  PutState *state = user_data;
  GCancellable *cancellable = handler_get_cancellable (state->handler);
  GError *err = NULL;
  gsize bytes_written;
  gconstpointer data;
  gsize data_length;

  if (state->too_large)
    return;

  g_debug ("PUT got chunk");

  data = g_bytes_get_data (chunk, &data_length);

  if (state->max_file_size > 0 &&
      ((guint64) data_length > state->max_file_size - MIN (state->received, state->max_file_size)))
    {
      state->too_large = TRUE;
      soup_server_message_set_status (msg, SOUP_STATUS_REQUEST_ENTITY_TOO_LARGE, NULL);
      return;
    }

  /*
   * total_before already includes the old destination file, if any.
   * Replacing it consumes only the delta:
   *   total_before - old_file_size + received + next_chunk
   */
  if (state->max_total_size > 0)
    {
      guint64 base = state->total_before >= state->old_file_size
                   ? state->total_before - state->old_file_size : 0;
      guint64 room = state->max_total_size > base
                   ? state->max_total_size - base : 0;

      if (state->received > room ||
          (guint64) data_length > room - MIN (state->received, room))
        {
          state->total_too_large = TRUE;
          soup_server_message_set_status (msg, SOUP_STATUS_INSUFFICIENT_STORAGE, NULL);
          return;
        }
    }

  if (!g_output_stream_write_all (G_OUTPUT_STREAM (state->output),
                                  data, data_length,
                                  &bytes_written, cancellable, &err))
    goto end;

  state->received += bytes_written;

end:
  if (err)
    {
      g_warning ("error: %s", err->message);
      g_clear_error (&err);
      soup_server_message_set_status (msg, SOUP_STATUS_INTERNAL_SERVER_ERROR, NULL);
    }
}

static gint
put_start (SoupServerMessage *msg, GFile *file,
           GFileOutputStream **output, GCancellable *cancellable,
           GError **err)
{
  GFileOutputStream *s = NULL;
  gchar *etag = NULL;
  gboolean created = TRUE;
  SoupMessageHeaders *headers = soup_server_message_get_request_headers (msg);
  gint status = SOUP_STATUS_INTERNAL_SERVER_ERROR;

  if (g_file_query_exists (file, cancellable))
    created = FALSE;

  if (soup_message_headers_get_list (headers, "If-Match"))
    g_warn_if_reached ();
  else if (soup_message_headers_get_list (headers, "If-None-Match"))
    g_warn_if_reached ();
  else if (soup_message_headers_get_list (headers, "Expect"))
    g_warn_if_reached ();

  s = g_file_replace (file, etag, FALSE, G_FILE_CREATE_PRIVATE, cancellable, err);
  if (!s)
    goto end;

  status = created ? SOUP_STATUS_CREATED : SOUP_STATUS_OK;

end:
  *output = s;
  return status;
}

void
phodav_method_put (PathHandler *handler, SoupServerMessage *msg, const gchar *path, GError **err)
{
  GCancellable *cancellable = handler_get_cancellable (handler);
  GFile *file = NULL;
  GList *submitted = NULL;
  GFileOutputStream *output = NULL;
  PutState *put_state = NULL;
  gint status;
  SoupMessageHeaders *request_headers = soup_server_message_get_request_headers (msg);

  g_debug ("%s %s HTTP/1.%d %s %s", soup_server_message_get_method (msg), path, soup_server_message_get_http_version (msg),
           soup_message_headers_get_one (request_headers, "X-Litmus") ? : "",
           soup_message_headers_get_one (request_headers, "X-Litmus-Second") ? : "");

  PhodavServer *server = handler_get_server (handler);
  goffset content_length = soup_message_headers_get_content_length (request_headers);

  /* PUT is an upload from the WebDAV client/guest to the host share. */
  if (!phodav_server_upload_is_enabled (server) || !phodav_server_path_is_allowed (server, path))
    {
      status = SOUP_STATUS_FORBIDDEN;
      goto end;
    }
  if (content_length > 0 && phodav_server_get_max_file_size (server) > 0 &&
      (guint64) content_length > phodav_server_get_max_file_size (server))
    { status = SOUP_STATUS_REQUEST_ENTITY_TOO_LARGE; goto end; }
  if (handler_get_readonly(handler))
    {
      status = SOUP_STATUS_FORBIDDEN;
      goto end;
    }

  status = phodav_check_if (handler, msg, path, &submitted);
  if (status != SOUP_STATUS_OK)
    goto end;

  file = g_file_get_child (handler_get_file (handler), path + 1);

  guint64 total_before = phodav_server_get_current_total_size (server);
  guint64 old_file_size = 0;
  GFileInfo *old_info = g_file_query_info (file,
                                            G_FILE_ATTRIBUTE_STANDARD_SIZE "," G_FILE_ATTRIBUTE_STANDARD_TYPE,
                                            G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS,
                                            cancellable, NULL);
  if (old_info)
    {
      if (g_file_info_get_file_type (old_info) == G_FILE_TYPE_REGULAR)
        old_file_size = g_file_info_get_size (old_info);
      g_object_unref (old_info);
    }

  if (phodav_server_get_max_total_size (server) > 0)
    {
      guint64 base = total_before >= old_file_size ? total_before - old_file_size : 0;
      guint64 limit = phodav_server_get_max_total_size (server);
      guint64 incoming = content_length > 0 ? (guint64) content_length : 0;

      /* Hard share quota: the final share size must fit the limit.
       * This also rejects a zero-byte NEW file when the share is already
       * over quota. Replacing an existing file is allowed only if the
       * resulting total fits the quota. */
      if (base > limit || incoming > limit - MIN (base, limit))
        {
          status = SOUP_STATUS_INSUFFICIENT_STORAGE;
          goto end;
        }
    }

  status = put_start (msg, file, &output, cancellable, err);
  if (!output || *err)
    goto end;

  phodav_server_session_mark_guest_created (server, path);

  g_debug ("PUT output %p", output);
  soup_message_body_set_accumulate (soup_server_message_get_request_body (msg), FALSE);

  put_state = g_new0 (PutState, 1);
  put_state->output = g_object_ref (output);
  put_state->file = g_object_ref (file);
  put_state->handler = handler;
  put_state->max_file_size = phodav_server_get_max_file_size (server);
  put_state->max_total_size = phodav_server_get_max_total_size (server);
  put_state->total_before = total_before;
  put_state->old_file_size = old_file_size;

  g_signal_connect (msg, "got-chunk", G_CALLBACK (method_put_got_chunk), put_state);
  g_signal_connect (msg, "finished", G_CALLBACK (method_put_finished), put_state);

end:
  soup_server_message_set_status (msg, status, NULL);
  g_clear_object (&output);
  g_clear_object (&file);
  g_debug ("  -> %d %s\n", soup_server_message_get_status (msg), soup_server_message_get_reason_phrase (msg));
}
