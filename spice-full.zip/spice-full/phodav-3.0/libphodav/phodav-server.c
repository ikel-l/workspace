/*
 * Copyright (C) 2013 Red Hat, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */

#include "config.h"

#include "guuid.h"
#include "phodav-server.h"
#include "phodav-multistatus.h"
#include "phodav-path.h"
#include "phodav-lock.h"
#include "phodav-utils.h"

/**
 * SECTION:phodav-server
 * @title: PhodavServer
 * @short_description: A WebDAV server
 * @see_also: #SoupServer
 * @stability: Stable
 * @include: libphodav/phodav.h
 *
 * PhodavServer implements a simple WebDAV server.
 */

struct _PhodavServer
{
  GObject       parent;
  SoupServer   *server;
  GCancellable *cancellable;
  GFile        *root_file;
  PathHandler  *root_handler; /* weak ref */
  GHashTable   *paths;
  gboolean      readonly;
  gboolean      upload_enabled;
  gboolean      download_enabled;
  guint64       max_file_size;
  guint64       max_total_size;
  gchar       **allowed_ext;
  gchar       **denied_ext;
  gchar       **hidden_patterns;
  GHashTable   *session_baseline;
  GHashTable   *session_guest_created;
};

struct _PhodavServerClass
{
  GObjectClass parent_class;
};

G_DEFINE_TYPE (PhodavServer, phodav_server, G_TYPE_OBJECT)

/* Properties */
enum {
  PROP_0,
  PROP_ROOT,
  PROP_ROOT_FILE,
  PROP_SERVER,
  PROP_READONLY,
};

static void server_callback (SoupServer        *server,
                             SoupServerMessage *msg,
                             const char        *path,
                             GHashTable        *query,
                             gpointer           user_data);

static void request_started (SoupServer        *server,
                             SoupServerMessage *message,
                             gpointer           user_data);

Path *
server_get_path (PhodavServer *self, const gchar *_path)
{
  Path *p;
  gchar *path = g_strdup (_path);

  remove_trailing (path, '/');
  p = g_hash_table_lookup (self->paths, path);
  if (!p)
    {
      p = g_slice_new0 (Path);
      p->path = path;
      g_hash_table_insert (self->paths, p->path, path_ref (p));
    }
  else
    {
      g_free (path);
    }

  return p;
}

struct _PathHandler
{
  PhodavServer *self;
  GFile       *file;
};

PhodavServer * G_GNUC_PURE
handler_get_server (PathHandler *handler)
{
  return handler->self;
}

GFile * G_GNUC_PURE
handler_get_file (PathHandler *handler)
{
  return handler->file;
}

GCancellable * G_GNUC_PURE
handler_get_cancellable (PathHandler *handler)
{
  return handler->self->cancellable;
}

gboolean G_GNUC_PURE
handler_get_readonly (PathHandler *handler)
{
  return handler->self->readonly;
}

static PathHandler *
path_handler_new (PhodavServer *self, GFile *file)
{
  PathHandler *h = g_slice_new0 (PathHandler);

  h->self = self;
  h->file = g_object_ref (file);
  return h;
}

static void
path_handler_free (PathHandler *h)
{
  g_object_unref (h->file);
  g_slice_free (PathHandler, h);
}

static void
phodav_server_init (PhodavServer *self)
{
  self->upload_enabled = TRUE;
  self->download_enabled = TRUE;
  self->cancellable = g_cancellable_new ();

  self->paths = g_hash_table_new_full (g_str_hash, g_str_equal,
                                       NULL, (GDestroyNotify) path_unref);
  self->session_baseline = g_hash_table_new_full (g_str_hash, g_str_equal, g_free, NULL);
  self->session_guest_created = g_hash_table_new_full (g_str_hash, g_str_equal, g_free, NULL);
}

static void
update_root_handler (PhodavServer *self)
{
  PathHandler *handler;

  if (!self->root_file || !self->server)
    return;

  handler = path_handler_new (self, self->root_file);

  soup_server_add_handler (self->server, "/",
                           server_callback,
                           handler,
                           (GDestroyNotify) path_handler_free);

  self->root_handler = handler;
}

static void
phodav_server_constructed (GObject *gobject)
{
  PhodavServer *self = PHODAV_SERVER (gobject);

  self->server = soup_server_new ("server-header", "PhodavServer ",
                                  NULL);

  update_root_handler (self);

  g_signal_connect (self->server, "request-started", G_CALLBACK (request_started), self);

  /* Chain up to the parent class */
  if (G_OBJECT_CLASS (phodav_server_parent_class)->constructed)
    G_OBJECT_CLASS (phodav_server_parent_class)->constructed (gobject);
}

static void
phodav_server_dispose (GObject *gobject)
{
  PhodavServer *self = PHODAV_SERVER (gobject);

  /* SoupServer could live longer than PhodavServer,
   * this frees the PhodavHandler passed as user_data */
  soup_server_remove_handler (self->server, "/");
  g_signal_handlers_disconnect_by_func (self->server, request_started, self);
  g_clear_object (&self->server);
  g_clear_object (&self->cancellable);
  g_clear_object (&self->root_file);
  g_clear_pointer (&self->allowed_ext, g_strfreev);
  g_clear_pointer (&self->denied_ext, g_strfreev);
  g_clear_pointer (&self->hidden_patterns, g_strfreev);
  g_clear_pointer (&self->paths, g_hash_table_unref);
  g_clear_pointer (&self->session_baseline, g_hash_table_unref);
  g_clear_pointer (&self->session_guest_created, g_hash_table_unref);

  /* Chain up to the parent class */
  if (G_OBJECT_CLASS (phodav_server_parent_class)->dispose)
    G_OBJECT_CLASS (phodav_server_parent_class)->dispose (gobject);
}

static void
phodav_server_get_property (GObject    *gobject,
                            guint       prop_id,
                            GValue     *value,
                            GParamSpec *pspec)
{
  PhodavServer *self = PHODAV_SERVER (gobject);

  switch (prop_id)
    {
    case PROP_ROOT:
      g_value_take_string (value, self->root_file ?
        g_file_get_path (self->root_file) : NULL);
      break;

    case PROP_ROOT_FILE:
      g_value_set_object (value, self->root_file);
      break;

    case PROP_SERVER:
      g_value_set_object (value, self->server);
      break;

    case PROP_READONLY:
      g_value_set_boolean (value, self->readonly);
      break;

    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (gobject, prop_id, pspec);
      break;
    }
}

static void
phodav_server_set_property (GObject      *gobject,
                            guint         prop_id,
                            const GValue *value,
                            GParamSpec   *pspec)
{
  PhodavServer *self = PHODAV_SERVER (gobject);
  const gchar *root;

  /* do not overwrite the root file during construction,
   * phodav should be constructed either with "root" or "root-file", not both */
  if (!self->server && self->root_file)
    return;

  switch (prop_id)
    {
    case PROP_ROOT:
      root = g_value_get_string (value);
      g_clear_object (&self->root_file);
      if (root)
        self->root_file = g_file_new_for_path (root);
      update_root_handler (self);
      break;

    case PROP_ROOT_FILE:
      g_clear_object (&self->root_file);
      self->root_file = g_value_dup_object (value);
      update_root_handler (self);
      break;

    case PROP_READONLY:
      self->readonly = g_value_get_boolean (value);
      break;

    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (gobject, prop_id, pspec);
      break;
    }
}

static void
phodav_server_class_init (PhodavServerClass *klass)
{
  GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

  gobject_class->dispose      = phodav_server_dispose;
  gobject_class->constructed  = phodav_server_constructed;
  gobject_class->get_property = phodav_server_get_property;
  gobject_class->set_property = phodav_server_set_property;

  /**
   * PhodavServer:root:
   *
   * This property is interconnected with the property #PhodavServer:root-file.
   * Changing #PhodavServer:root affects #PhodavServer:root-file and vice versa.
   *
   * You can use either of them or none to construct a new #PhodavServer,
   * you should not use both.
   **/
  g_object_class_install_property
    (gobject_class, PROP_ROOT,
    g_param_spec_string ("root",
                         "Root path",
                         "Root path",
                         NULL,
                         G_PARAM_CONSTRUCT |
                         G_PARAM_READWRITE |
                         G_PARAM_STATIC_STRINGS));

/**
   * PhodavServer:root-file:
   *
   * A more generic version of #PhodavServer:root,
   * see it for more details.
   *
   * Since: 2.5
   **/
  g_object_class_install_property
    (gobject_class, PROP_ROOT_FILE,
     g_param_spec_object ("root-file",
                          "Root file",
                          "Root file",
                          G_TYPE_FILE,
                          G_PARAM_CONSTRUCT |
                          G_PARAM_READWRITE |
                          G_PARAM_STATIC_STRINGS));

  g_object_class_install_property
    (gobject_class, PROP_SERVER,
     g_param_spec_object ("server",
                          "Soup Server",
                          "Soup Server",
                          SOUP_TYPE_SERVER,
                          G_PARAM_READABLE |
                          G_PARAM_STATIC_STRINGS));

  g_object_class_install_property
    (gobject_class, PROP_READONLY,
     g_param_spec_boolean ("read-only",
                           "Read-only access",
                           "Read-only access",
                           FALSE,
                           G_PARAM_READWRITE |
                           G_PARAM_STATIC_STRINGS));
}

gboolean
server_foreach_parent_path (PhodavServer *self, const gchar *path, PathCb cb, gpointer data)
{
  gchar **pathv, *partial = g_strdup ("/");
  gboolean ret = FALSE;
  gchar *key = NULL;
  Path *p;
  gint i;

  pathv = g_strsplit (path, "/", -1);

  for (i = 0; pathv[i]; i++)
    {
      if (!*pathv[i])
        continue;

      gchar *tmp = g_build_path ("/", partial, pathv[i], NULL);
      g_free (partial);
      partial = tmp;

      if (g_hash_table_lookup_extended (self->paths, partial,
                                        (gpointer *) &key, (gpointer *) &p))
        {
          if (!cb (key, p, data))
            goto end;
        }
    }

  ret = TRUE;

end:
  g_strfreev (pathv);
  g_free (partial);

  return ret;
}

typedef struct _PathGetLock
{
  const gchar *token;
  DAVLock     *lock;
} PathGetLock;

static gboolean
_path_get_lock (const gchar *key, Path *path, gpointer data)
{
  PathGetLock *d = data;
  GList *l;

  for (l = path->locks; l != NULL; l = l->next)
    {
      DAVLock *lock = l->data;

      if (!g_strcmp0 (lock->token, d->token))
        {
          d->lock = lock;
          return FALSE;
        }
    }

  return TRUE;
}

DAVLock *
server_path_get_lock (PhodavServer *self, const gchar *path, const gchar *token)
{
  PathGetLock p = { .token = token };
  gboolean success = !server_foreach_parent_path (self, path,
                                                  _path_get_lock, (gpointer) &p);

  if (!success)
    g_message ("Invalid lock token %s for %s", token, path);

  return p.lock;
}

static gboolean
other_lock_exists (const gchar *key, Path *path, gpointer data)
{
  GList *locks = data;
  GList *l;

  for (l = path->locks; l != NULL; l = l->next)
    {
      DAVLock *lock = l->data;
      if (!locks_submitted_has (locks, lock))
        return FALSE;
    }

  return TRUE;
}

gboolean
server_path_has_other_locks (PhodavServer *self, const gchar *path, GList *locks)
{
  return !server_foreach_parent_path (self, path, other_lock_exists, locks);
}

static void
got_headers (SoupServerMessage *msg,
             gpointer     user_data)
{
  PhodavServer *self = user_data;
  GUri *uri = soup_server_message_get_uri (msg);
  const gchar *path = g_uri_get_path (uri);
  GError *err = NULL;

  if (soup_server_message_get_method (msg) == SOUP_METHOD_PUT)
    phodav_method_put (self->root_handler, msg, path, &err);

  if (err)
    {
      g_warning ("error: %s", err->message);
      g_clear_error (&err);
    }
}

static void
request_started (SoupServer        *server,
                 SoupServerMessage *message,
                 gpointer           user_data)
{
  PhodavServer *self = user_data;

  g_signal_connect (message, "got-headers", G_CALLBACK (got_headers), self);
}

static void
server_callback (SoupServer *server, SoupServerMessage *msg,
                 const char *path, GHashTable *query,
                 gpointer user_data)
{
  GError *err = NULL;
  PathHandler *handler = user_data;
  gint status = SOUP_STATUS_NOT_IMPLEMENTED;
  GUri *uri = soup_server_message_get_uri (msg);
  const char *method = soup_server_message_get_method (msg);
  SoupMessageHeaders *request_headers = soup_server_message_get_request_headers (msg);
  SoupMessageHeaders *response_headers;
  GHashTable *params;

  g_debug ("%s %s HTTP/1.%d %s %s", method, path, soup_server_message_get_http_version (msg),
           soup_message_headers_get_one (request_headers, "X-Litmus") ? : "",
           soup_message_headers_get_one (request_headers, "X-Litmus-Second") ? : "");

  if (!(path && *path == '/'))
    {
      g_debug ("path must begin with /");
      return;
    }
  if (!(uri && g_uri_get_fragment (uri) == NULL))
    {
      g_debug ("using fragments in query is not supported");
      return;
    }

  params = g_hash_table_new_full (g_str_hash, g_str_equal, g_free, g_free);
  g_hash_table_insert (params, g_strdup ("charset"), g_strdup ("utf-8"));
  response_headers = soup_server_message_get_response_headers (msg);
  soup_message_headers_set_content_type (response_headers,
                                         "text/xml", params);
  g_hash_table_destroy (params);

  {
    GFileType file_type;

    /* A new MKCOL target does not exist yet, so it cannot be detected via
     * GIO.  Treat it as a directory explicitly.  For all other methods,
     * query the existing target; UNKNOWN is intentionally handled as a file
     * by the policy helper so uploads to new files remain filtered. */
    if (method == SOUP_METHOD_MKCOL)
      file_type = G_FILE_TYPE_DIRECTORY;
    else
      {
        GFile *file = g_file_get_child (handler_get_file (handler), path + 1);
        file_type = g_file_query_file_type (file, G_FILE_QUERY_INFO_NONE,
                                            handler->self->cancellable);
        g_object_unref (file);
      }

    if (!phodav_server_path_is_allowed_for_type (handler->self, path, file_type))
      status = SOUP_STATUS_NOT_FOUND;
  /*
   * WebDAV policy directions are named from the client's point of view:
   *   upload   = guest/client -> host/shared directory (write operations)
   *   download = host/shared directory -> guest/client (read operations)
   * Keep discovery/navigation methods (OPTIONS/PROPFIND) available so the
   * share remains browsable on Windows, Linux and macOS.
   */
    else if (!handler->self->download_enabled &&
           (method == SOUP_METHOD_GET || method == SOUP_METHOD_HEAD) &&
           !phodav_server_session_path_visible (handler->self, path))
    status = SOUP_STATUS_NOT_FOUND;
    else if (!handler->self->upload_enabled &&
           (method == SOUP_METHOD_PUT || method == SOUP_METHOD_PROPPATCH ||
            method == SOUP_METHOD_MKCOL || method == SOUP_METHOD_DELETE ||
            method == SOUP_METHOD_MOVE || method == SOUP_METHOD_COPY ||
            method == SOUP_METHOD_LOCK || method == SOUP_METHOD_UNLOCK))
    status = SOUP_STATUS_FORBIDDEN;
    else if (handler->self->readonly &&
      (method == SOUP_METHOD_PUT || method == SOUP_METHOD_PROPPATCH ||
       method == SOUP_METHOD_MKCOL ||
       method == SOUP_METHOD_DELETE ||
       method == SOUP_METHOD_MOVE ||
       method == SOUP_METHOD_COPY ||
       method == SOUP_METHOD_LOCK))
      status = SOUP_STATUS_FORBIDDEN;
    else if (method == SOUP_METHOD_OPTIONS)
      {
      soup_message_headers_append (response_headers, "DAV", "1,2");

      /* according to http://code.google.com/p/sabredav/wiki/Windows */
      soup_message_headers_append (response_headers, "MS-Author-Via", "DAV");

      soup_message_headers_append (response_headers, "Allow",
                                   "GET, HEAD, PUT, PROPFIND, PROPPATCH, MKCOL, DELETE, MOVE, COPY, LOCK, UNLOCK");
      status = SOUP_STATUS_OK;
    }
  else if (method == SOUP_METHOD_GET ||
           method == SOUP_METHOD_HEAD)
    status = phodav_method_get (handler, msg, path, &err);
  else if (method == SOUP_METHOD_PROPFIND)
    status = phodav_method_propfind (handler, msg, path, &err);
  else if (method == SOUP_METHOD_PROPPATCH)
    status = phodav_method_proppatch (handler, msg, path, &err);
  else if (method == SOUP_METHOD_MKCOL)
    status = phodav_method_mkcol (handler, msg, path, &err);
  else if (method == SOUP_METHOD_DELETE)
    status = phodav_method_delete (handler, msg, path, &err);
  else if (method == SOUP_METHOD_MOVE ||
           method == SOUP_METHOD_COPY)
    status = phodav_method_movecopy (handler, msg, path, &err);
  else if (method == SOUP_METHOD_LOCK)
    status = phodav_method_lock (handler, msg, path, &err);
  else if (method == SOUP_METHOD_UNLOCK)
    status = phodav_method_unlock (handler, msg, path, &err);
  else
    g_warn_if_reached ();
  }

  soup_server_message_set_status (msg, status, NULL);

  g_debug ("  -> %d %s\n", soup_server_message_get_status (msg), soup_server_message_get_reason_phrase (msg));
  if (err)
    {
      g_warning ("error: %s", err->message);
      g_clear_error (&err);
    }
}

/**
 * phodav_server_get_soup_server:
 * @server: a %PhodavServer
 *
 * Returns the underlying %SoupServer, if any.
 *
 * Returns: the associated %SoupServer or %NULL
 **/
SoupServer *
phodav_server_get_soup_server (PhodavServer *self)
{
  g_return_val_if_fail (PHODAV_IS_SERVER (self), NULL);

  return self->server;
}

/**
 * phodav_server_new:
 * @root: (allow-none): Root path.
 *
 * Creates a new #PhodavServer.
 * This is equivalent to constructing a #GFile from @root
 * and using phodav_server_new_for_root_file().
 *
 * Returns: a new #PhodavServer
 **/
PhodavServer *
phodav_server_new (const gchar *root)
{
  return g_object_new (PHODAV_TYPE_SERVER,
                       "root", root,
                       NULL);
}

/**
 * phodav_server_new_for_root_file:
 * @root: (nullable): a #GFile specifying the root
 *
 * Creates a new #PhodavServer and publishes the files under @root.
 *
 * Returns: (transfer full): a new #PhodavServer
 *
 * Since: 2.5
 **/
PhodavServer *
phodav_server_new_for_root_file (GFile *root)
{
  return g_object_new (PHODAV_TYPE_SERVER,
                       "root-file",
                       root,
                       NULL);
}


static gchar **split_policy_list (const gchar *value)
{
  gchar **items, **p;
  if (!value || !*value) return NULL;
  items = g_strsplit (value, ",", -1);
  for (p = items; *p; p++) g_strstrip (*p);
  return items;
}

static gchar *session_normalize_path (const gchar *path)
{
  gchar *decoded, *norm;
  if (!path || !*path) return g_strdup ("/");
  decoded = g_uri_unescape_string (path, NULL);
  norm = g_strdup (decoded ? decoded : path);
  g_free (decoded);
  if (norm[0] != '/') {
    gchar *tmp = g_strconcat ("/", norm, NULL);
    g_free (norm);
    norm = tmp;
  }
  while (strlen (norm) > 1 && norm[strlen (norm) - 1] == '/')
    norm[strlen (norm) - 1] = '\0';
  return norm;
}

static void session_snapshot_walk (PhodavServer *self, GFile *dir, const gchar *uri_path)
{
  GFileEnumerator *e;
  GError *err = NULL;
  GFileInfo *info;

  g_hash_table_add (self->session_baseline, session_normalize_path (uri_path));
  e = g_file_enumerate_children (dir, "standard::name,standard::type",
                                 G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS,
                                 self->cancellable, &err);
  if (!e) {
    g_clear_error (&err);
    return;
  }
  while ((info = g_file_enumerator_next_file (e, self->cancellable, &err)) != NULL) {
    const gchar *name = g_file_info_get_name (info);
    gchar *child_path = !g_strcmp0 (uri_path, "/")
      ? g_strconcat ("/", name, NULL)
      : g_strconcat (uri_path, "/", name, NULL);
    GFile *child = g_file_get_child (dir, name);
    g_hash_table_add (self->session_baseline, session_normalize_path (child_path));
    if (g_file_info_get_file_type (info) == G_FILE_TYPE_DIRECTORY)
      session_snapshot_walk (self, child, child_path);
    g_object_unref (child);
    g_free (child_path);
    g_object_unref (info);
  }
  g_clear_error (&err);
  g_file_enumerator_close (e, self->cancellable, NULL);
  g_object_unref (e);
}

void phodav_server_set_upload_enabled (PhodavServer *self, gboolean enabled)
{
  g_return_if_fail (PHODAV_IS_SERVER (self));
  self->upload_enabled = enabled;
}

void phodav_server_set_download_enabled (PhodavServer *self, gboolean enabled)
{
  g_return_if_fail (PHODAV_IS_SERVER (self));
  if (!enabled && self->download_enabled) {
    g_hash_table_remove_all (self->session_baseline);
    g_hash_table_remove_all (self->session_guest_created);
    if (self->root_file)
      session_snapshot_walk (self, self->root_file, "/");
  }
  if (enabled) {
    g_hash_table_remove_all (self->session_baseline);
    g_hash_table_remove_all (self->session_guest_created);
  }
  self->download_enabled = enabled;
}

gboolean phodav_server_session_path_visible (PhodavServer *self, const gchar *path)
{
  gchar *norm;
  gboolean visible;
  g_return_val_if_fail (PHODAV_IS_SERVER (self), FALSE);
  if (self->download_enabled) return TRUE;
  norm = session_normalize_path (path);
  visible = g_hash_table_contains (self->session_baseline, norm) ||
            g_hash_table_contains (self->session_guest_created, norm);
  g_free (norm);
  return visible;
}

void phodav_server_session_mark_guest_created (PhodavServer *self, const gchar *path)
{
  gchar *norm;
  g_return_if_fail (PHODAV_IS_SERVER (self));
  if (self->download_enabled) return;
  norm = session_normalize_path (path);
  g_hash_table_add (self->session_guest_created, norm);
}

static void session_mark_guest_tree_walk (PhodavServer *self, GFile *file, const gchar *uri_path)
{
  GFileType type;
  GFileEnumerator *e;
  GError *err = NULL;
  GFileInfo *info;

  phodav_server_session_mark_guest_created (self, uri_path);
  type = g_file_query_file_type (file, G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS, self->cancellable);
  if (type != G_FILE_TYPE_DIRECTORY) return;
  e = g_file_enumerate_children (file, "standard::name,standard::type",
                                 G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS,
                                 self->cancellable, &err);
  if (!e) { g_clear_error (&err); return; }
  while ((info = g_file_enumerator_next_file (e, self->cancellable, &err)) != NULL) {
    const gchar *name = g_file_info_get_name (info);
    gchar *child_path = !g_strcmp0 (uri_path, "/")
      ? g_strconcat ("/", name, NULL)
      : g_strconcat (uri_path, "/", name, NULL);
    GFile *child = g_file_get_child (file, name);
    session_mark_guest_tree_walk (self, child, child_path);
    g_object_unref (child);
    g_free (child_path);
    g_object_unref (info);
  }
  g_clear_error (&err);
  g_file_enumerator_close (e, self->cancellable, NULL);
  g_object_unref (e);
}

void phodav_server_session_mark_guest_tree (PhodavServer *self, const gchar *path)
{
  gchar *decoded;
  GFile *file;
  g_return_if_fail (PHODAV_IS_SERVER (self));
  if (self->download_enabled || !self->root_file) return;
  decoded = g_uri_unescape_string (path && path[0] == '/' ? path + 1 : path, NULL);
  file = g_file_get_child (self->root_file, decoded ? decoded : "");
  session_mark_guest_tree_walk (self, file, path);
  g_object_unref (file);
  g_free (decoded);
}

void phodav_server_session_unmark_guest_path (PhodavServer *self, const gchar *path)
{
  gchar *norm;
  GHashTableIter iter;
  gpointer key;
  g_return_if_fail (PHODAV_IS_SERVER (self));
  norm = session_normalize_path (path);
  g_hash_table_iter_init (&iter, self->session_guest_created);
  while (g_hash_table_iter_next (&iter, &key, NULL)) {
    const gchar *p = key;
    gsize n = strlen (norm);
    if (!g_strcmp0 (p, norm) || (g_str_has_prefix (p, norm) && p[n] == '/'))
      g_hash_table_iter_remove (&iter);
  }
  g_free (norm);
}
void phodav_server_set_max_file_size (PhodavServer *self, guint64 bytes) { g_return_if_fail (PHODAV_IS_SERVER (self)); self->max_file_size = bytes; }
void phodav_server_set_max_total_size (PhodavServer *self, guint64 bytes) { g_return_if_fail (PHODAV_IS_SERVER (self)); self->max_total_size = bytes; }
void phodav_server_set_allowed_extensions (PhodavServer *self, const gchar *v) { g_return_if_fail (PHODAV_IS_SERVER (self)); g_strfreev (self->allowed_ext); self->allowed_ext = split_policy_list (v); }
void phodav_server_set_denied_extensions (PhodavServer *self, const gchar *v) { g_return_if_fail (PHODAV_IS_SERVER (self)); g_strfreev (self->denied_ext); self->denied_ext = split_policy_list (v); }
void phodav_server_set_hidden_patterns (PhodavServer *self, const gchar *v) { g_return_if_fail (PHODAV_IS_SERVER (self)); g_strfreev (self->hidden_patterns); self->hidden_patterns = split_policy_list (v); }
gboolean phodav_server_upload_is_enabled (PhodavServer *self) { return self->upload_enabled; }
gboolean phodav_server_download_is_enabled (PhodavServer *self) { return self->download_enabled; }
guint64 phodav_server_get_max_file_size (PhodavServer *self) { return self->max_file_size; }
guint64 phodav_server_get_max_total_size (PhodavServer *self) { return self->max_total_size; }

static gboolean list_has_ext (gchar **list, const gchar *ext)
{
  gint i; if (!list || !ext) return FALSE;
  for (i = 0; list[i]; i++) { const gchar *x = list[i][0] == '.' ? list[i] + 1 : list[i]; if (g_ascii_strcasecmp (x, ext) == 0) return TRUE; }
  return FALSE;
}

gboolean phodav_server_path_is_allowed_for_type (PhodavServer *self,
                                                  const gchar *path,
                                                  GFileType type)
{
  gchar *decoded, *base, *dot; gint i; gboolean ok = TRUE;
  if (!path || !g_strcmp0 (path, "/")) return TRUE;
  decoded = g_uri_unescape_string (path, NULL); base = g_path_get_basename (decoded ? decoded : path);
  if (self->hidden_patterns) for (i = 0; self->hidden_patterns[i]; i++) if (g_pattern_match_simple (self->hidden_patterns[i], base)) { ok = FALSE; goto out; }

  /* Extension policies describe files, not WebDAV collections.  This is
   * deliberately based on GFileType instead of filename syntax so directory
   * names such as "folder.exe" stay navigable on every platform. */
  if (type != G_FILE_TYPE_REGULAR && type != G_FILE_TYPE_UNKNOWN)
    goto out;

  dot = strrchr (base, '.');
  if (dot && dot != base && dot[1]) {
    if (list_has_ext (self->denied_ext, dot + 1)) { ok = FALSE; goto out; }
    if (self->allowed_ext && self->allowed_ext[0] && !list_has_ext (self->allowed_ext, dot + 1)) { ok = FALSE; goto out; }
  } else {
    if (list_has_ext (self->denied_ext, "none")) { ok = FALSE; goto out; }
    if (self->allowed_ext && self->allowed_ext[0] && !list_has_ext (self->allowed_ext, "none")) { ok = FALSE; }
  }
out: g_free (base); g_free (decoded); return ok;
}

gboolean phodav_server_path_is_allowed (PhodavServer *self, const gchar *path)
{
  /* Callers that validate a new upload do not have a GFileType yet. */
  return phodav_server_path_is_allowed_for_type (self, path,
                                                  G_FILE_TYPE_REGULAR);
}

static guint64 dir_size (GFile *dir, GCancellable *c)
{
  guint64 total = 0; GFileEnumerator *e; GFileInfo *info;
  e = g_file_enumerate_children (dir, "standard::name,standard::type,standard::size", G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS, c, NULL);
  if (!e) return 0;
  while ((info = g_file_enumerator_next_file (e, c, NULL))) {
    if (g_file_info_get_file_type (info) == G_FILE_TYPE_DIRECTORY) { GFile *child = g_file_get_child (dir, g_file_info_get_name (info)); total += dir_size (child, c); g_object_unref (child); }
    else if (g_file_info_get_file_type (info) == G_FILE_TYPE_REGULAR) total += g_file_info_get_size (info);
    g_object_unref (info);
  }
  g_object_unref (e); return total;
}
guint64 phodav_server_get_current_total_size (PhodavServer *self) { return self->root_file ? dir_size (self->root_file, self->cancellable) : 0; }

guint64
phodav_server_get_path_size (PhodavServer *self, const gchar *path)
{
  GFile *file;
  GFileType type;
  GFileInfo *info;
  guint64 size = 0;
  gchar *decoded;

  g_return_val_if_fail (PHODAV_IS_SERVER (self), 0);
  if (!self->root_file || !path)
    return 0;

  decoded = g_uri_unescape_string (path[0] == '/' ? path + 1 : path, NULL);
  file = g_file_get_child (self->root_file, decoded ? decoded : "");
  g_free (decoded);

  type = g_file_query_file_type (file, G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS, self->cancellable);
  if (type == G_FILE_TYPE_DIRECTORY)
    size = dir_size (file, self->cancellable);
  else if (type == G_FILE_TYPE_REGULAR)
    {
      info = g_file_query_info (file, G_FILE_ATTRIBUTE_STANDARD_SIZE,
                                G_FILE_QUERY_INFO_NOFOLLOW_SYMLINKS,
                                self->cancellable, NULL);
      if (info)
        {
          size = g_file_info_get_size (info);
          g_object_unref (info);
        }
    }

  g_object_unref (file);
  return size;
}
