if spice_gtk_has_polkit
  install_data('ru.gorizont.vdi.lowlevelusbaccess.policy',
               install_dir : spice_gtk_policy_dir)
endif
