/* gorizont-cb-proto.h — Gorizont-VS-VDI clipboard extension protocol
 *
 * Defines custom VDAgentMessage types and data structures for the
 * Gorizont virtual clipboard extension protocol that runs on top of
 * the standard SPICE VirtIO agent channel.
 *
 * IMPORTANT: This header is intentionally duplicated in:
 *   spice-gtk/src/gorizont-cb-proto.h      (host / spice-gtk side)
 *   vd_agent/src/gorizont-cb-proto.h       (guest / vdagentd side)
 * Keep both copies in sync.  A mismatch is a protocol bug.
 *
 * Custom message type values start at 0x4700 ('G' = 0x47 in ASCII).
 * This range is intentionally far above the standard SPICE agent message
 * range (currently 1–16) to avoid collisions with future upstream types.
 * vdagentd intercepts these messages BEFORE the standard size-check array.
 */

#pragma once

#include <stdint.h>

/* ------------------------------------------------------------------ */
/* Message types                                                       */

#define VD_AGENT_GORIZONT_CAPS_REQUEST   0x4700u
#define VD_AGENT_GORIZONT_CAPS_RESPONSE  0x4701u

/* ------------------------------------------------------------------ */
/* Protocol version                                                    */

#define GORIZONT_PROTOCOL_VERSION 1u

/* ------------------------------------------------------------------ */
/* Capability bits (sent in VDAgentGorizontCaps.caps)                 */

#define GORIZONT_CAP_LAZY_FILE_CB  (1u << 0)  /* lazy virtual-file clipboard */
#define GORIZONT_CAP_HTML_CB       (1u << 1)  /* text/html clipboard */
#define GORIZONT_CAP_IMAGE_CB      (1u << 2)  /* image clipboard */
#define GORIZONT_CAP_MULTI_FILE_CB (1u << 3)  /* multi-file metadata */
#define GORIZONT_CAP_TIMEZONE      (1u << 4)  /* host timezone sync */

/* ------------------------------------------------------------------ */
/* Payload struct (same layout for request and response)               */

#pragma pack(push, 1)
typedef struct {
    uint32_t version;  /* GORIZONT_PROTOCOL_VERSION, little-endian */
    uint32_t caps;     /* bitmask of GORIZONT_CAP_*, little-endian  */
} VDAgentGorizontCaps;
#pragma pack(pop)

#define VD_AGENT_GORIZONT_SET_TIMEZONE 0x4740u
#define GORIZONT_TIMEZONE_MAX_LEN 128u

#pragma pack(push, 1)
typedef struct {
    uint32_t version;
    uint32_t name_len;
    char name[GORIZONT_TIMEZONE_MAX_LEN];
} VDAgentGorizontTimezone;
#pragma pack(pop)

/* ================================================================== */
/* File clipboard metadata (Phase 4+)                                  */
/* ================================================================== */

#define VD_AGENT_GORIZONT_CLIPBOARD_FILE_META  0x2000u
#define VD_AGENT_GORIZONT_CLIPBOARD_HTML       0x2001u

#define GORIZONT_FILE_META_ATOM  "application/x-gorizont-file-meta"
#define GORIZONT_HTML_ATOM       "text/html"

#define GORIZONT_DIRECTION_HOST_TO_GUEST  0
#define GORIZONT_DIRECTION_GUEST_TO_HOST  1

#define GORIZONT_ITEM_KIND_FILE    0
#define GORIZONT_ITEM_KIND_FOLDER  1
#define GORIZONT_ITEM_KIND_ARCHIVE 2

#define GORIZONT_FILE_ID_LEN  16

#pragma pack(push, 1)
typedef struct {
    uint8_t  protocol;
    uint8_t  n_items;
    uint8_t  direction;
    uint8_t  _pad;
    uint32_t generation;
    char     clipboard_id[37];
    uint8_t  _pad2[3];
} VDAgentGorizontMetaHeader;    /* 48 bytes */

typedef struct {
    uint8_t  kind;
    uint8_t  _pad[3];
    uint32_t name_len;
    uint64_t size;
    uint64_t mtime;
    char     file_id[GORIZONT_FILE_ID_LEN];
    /* char name[name_len] follows, UTF-8, no null terminator */
} VDAgentGorizontMetaItem;      /* 40 bytes */
#pragma pack(pop)

/* File transfer messages (Phase 5+) */
#define VD_AGENT_GORIZONT_FILE_OPEN_REQUEST  0x4720u
#define VD_AGENT_GORIZONT_FILE_CHUNK         0x4721u
#define VD_AGENT_GORIZONT_FILE_CLOSE         0x4722u
#define VD_AGENT_GORIZONT_FILE_CANCEL        0x4723u
#define VD_AGENT_GORIZONT_FILE_ERROR         0x4724u

#define GORIZONT_CHUNK_SIZE  (1u * 1024u * 1024u)

#define GORIZONT_CANCEL_USER   0u
#define GORIZONT_CANCEL_ERROR  1u

#define GORIZONT_ERR_NOT_FOUND   1u
#define GORIZONT_ERR_OPEN_FAILED 2u
#define GORIZONT_ERR_READ_FAILED 3u
#define GORIZONT_ERR_CHANGED     4u
#define GORIZONT_ERR_POLICY      5u

#pragma pack(push, 1)
typedef struct {
    char clipboard_id[37];
    uint8_t  _pad[3];
    char file_id[GORIZONT_FILE_ID_LEN];
} VDAgentGorizontFileOpenRequest;   /* 56 bytes */

typedef struct {
    char     clipboard_id[37];
    uint8_t  _pad[3];
    char     file_id[GORIZONT_FILE_ID_LEN];
    uint64_t offset;
    uint32_t data_len;
    /* uint8_t data[data_len] follows */
} VDAgentGorizontFileChunk;         /* 68 bytes + data */

typedef struct {
    char     clipboard_id[37];
    uint8_t  _pad[3];
    char     file_id[GORIZONT_FILE_ID_LEN];
    uint64_t total_bytes;
} VDAgentGorizontFileClose;         /* 64 bytes */

typedef struct {
    char     clipboard_id[37];
    uint8_t  _pad[3];
    char     file_id[GORIZONT_FILE_ID_LEN];
    uint32_t reason;
} VDAgentGorizontFileCancel;        /* 60 bytes */

typedef struct {
    char     clipboard_id[37];
    uint8_t  _pad[3];
    char     file_id[GORIZONT_FILE_ID_LEN];
    uint32_t error_code;
} VDAgentGorizontFileError;         /* 60 bytes */
#pragma pack(pop)
