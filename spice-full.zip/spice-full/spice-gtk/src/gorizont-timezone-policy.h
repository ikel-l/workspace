/* Windows mappings derived from Unicode CLDR windowsZones.xml.
 * Copyright Unicode, Inc. Distributed under the Unicode License v3.
 * https://www.unicode.org/license.txt
 */
#ifndef GORIZONT_TIMEZONE_POLICY_H
#define GORIZONT_TIMEZONE_POLICY_H
#include <glib.h>
#include <string.h>

static inline gboolean gorizont_timezone_name_valid(const gchar *name)
{
    const gchar *part;
    if (!name || !*name || strlen(name) >= 128 || name[0] == '/')
        return FALSE;
    part = name;
    for (const gchar *p = name; ; p++) {
        if (*p == '/' || !*p) {
            if (p == part || (p-part == 1 && part[0] == '.') ||
                (p-part == 2 && part[0] == '.' && part[1] == '.'))
                return FALSE;
            part = p + 1;
            if (!*p) break;
        } else if (!(g_ascii_isalnum(*p) || *p == '_' || *p == '-' || *p == '+')) {
            return FALSE;
        }
    }
    return strchr(name, '/') != NULL || !strcmp(name, "UTC") || !strcmp(name, "GMT");
}

static inline gboolean gorizont_timezone_policy_valid(const gchar *policy)
{
    return policy && (!strcmp(policy, "allow") || !strcmp(policy, "deny") ||
        (g_str_has_prefix(policy, "force:") && gorizont_timezone_name_valid(policy + 6)));
}

#ifdef G_OS_WIN32
#include <windows.h>
static inline gchar *gorizont_windows_timezone(void)
{
    static const struct { const gchar *windows; const gchar *iana; } zones[] = {
        { "Dateline Standard Time", "Etc/GMT+12" },
        { "UTC-11", "Etc/GMT+11" },
        { "Aleutian Standard Time", "America/Adak" },
        { "Hawaiian Standard Time", "Pacific/Honolulu" },
        { "Marquesas Standard Time", "Pacific/Marquesas" },
        { "Alaskan Standard Time", "America/Anchorage" },
        { "UTC-09", "Etc/GMT+9" },
        { "Pacific Standard Time (Mexico)", "America/Tijuana" },
        { "UTC-08", "Etc/GMT+8" },
        { "Pacific Standard Time", "America/Los_Angeles" },
        { "US Mountain Standard Time", "America/Phoenix" },
        { "Mountain Standard Time (Mexico)", "America/Mazatlan" },
        { "Mountain Standard Time", "America/Denver" },
        { "Yukon Standard Time", "America/Whitehorse" },
        { "Central America Standard Time", "America/Guatemala" },
        { "Central Standard Time", "America/Chicago" },
        { "Easter Island Standard Time", "Pacific/Easter" },
        { "Central Standard Time (Mexico)", "America/Mexico_City" },
        { "Canada Central Standard Time", "America/Regina" },
        { "SA Pacific Standard Time", "America/Bogota" },
        { "Eastern Standard Time (Mexico)", "America/Cancun" },
        { "Eastern Standard Time", "America/New_York" },
        { "Haiti Standard Time", "America/Port-au-Prince" },
        { "Cuba Standard Time", "America/Havana" },
        { "US Eastern Standard Time", "America/Indianapolis" },
        { "Turks And Caicos Standard Time", "America/Grand_Turk" },
        { "Paraguay Standard Time", "America/Asuncion" },
        { "Atlantic Standard Time", "America/Halifax" },
        { "Venezuela Standard Time", "America/Caracas" },
        { "Central Brazilian Standard Time", "America/Cuiaba" },
        { "SA Western Standard Time", "America/La_Paz" },
        { "Pacific SA Standard Time", "America/Santiago" },
        { "Newfoundland Standard Time", "America/St_Johns" },
        { "Tocantins Standard Time", "America/Araguaina" },
        { "E. South America Standard Time", "America/Sao_Paulo" },
        { "SA Eastern Standard Time", "America/Cayenne" },
        { "Argentina Standard Time", "America/Buenos_Aires" },
        { "Greenland Standard Time", "America/Godthab" },
        { "Montevideo Standard Time", "America/Montevideo" },
        { "Magallanes Standard Time", "America/Punta_Arenas" },
        { "Saint Pierre Standard Time", "America/Miquelon" },
        { "Bahia Standard Time", "America/Bahia" },
        { "UTC-02", "Etc/GMT+2" },
        { "Azores Standard Time", "Atlantic/Azores" },
        { "Cape Verde Standard Time", "Atlantic/Cape_Verde" },
        { "UTC", "Etc/UTC" },
        { "GMT Standard Time", "Europe/London" },
        { "Greenwich Standard Time", "Atlantic/Reykjavik" },
        { "Sao Tome Standard Time", "Africa/Sao_Tome" },
        { "Morocco Standard Time", "Africa/Casablanca" },
        { "W. Europe Standard Time", "Europe/Berlin" },
        { "Central Europe Standard Time", "Europe/Budapest" },
        { "Romance Standard Time", "Europe/Paris" },
        { "Central European Standard Time", "Europe/Warsaw" },
        { "W. Central Africa Standard Time", "Africa/Lagos" },
        { "Jordan Standard Time", "Asia/Amman" },
        { "GTB Standard Time", "Europe/Bucharest" },
        { "Middle East Standard Time", "Asia/Beirut" },
        { "Egypt Standard Time", "Africa/Cairo" },
        { "E. Europe Standard Time", "Europe/Chisinau" },
        { "Syria Standard Time", "Asia/Damascus" },
        { "West Bank Standard Time", "Asia/Hebron" },
        { "South Africa Standard Time", "Africa/Johannesburg" },
        { "FLE Standard Time", "Europe/Kiev" },
        { "Israel Standard Time", "Asia/Jerusalem" },
        { "South Sudan Standard Time", "Africa/Juba" },
        { "Kaliningrad Standard Time", "Europe/Kaliningrad" },
        { "Sudan Standard Time", "Africa/Khartoum" },
        { "Libya Standard Time", "Africa/Tripoli" },
        { "Namibia Standard Time", "Africa/Windhoek" },
        { "Arabic Standard Time", "Asia/Baghdad" },
        { "Turkey Standard Time", "Europe/Istanbul" },
        { "Arab Standard Time", "Asia/Riyadh" },
        { "Belarus Standard Time", "Europe/Minsk" },
        { "Russian Standard Time", "Europe/Moscow" },
        { "E. Africa Standard Time", "Africa/Nairobi" },
        { "Iran Standard Time", "Asia/Tehran" },
        { "Arabian Standard Time", "Asia/Dubai" },
        { "Astrakhan Standard Time", "Europe/Astrakhan" },
        { "Azerbaijan Standard Time", "Asia/Baku" },
        { "Russia Time Zone 3", "Europe/Samara" },
        { "Mauritius Standard Time", "Indian/Mauritius" },
        { "Saratov Standard Time", "Europe/Saratov" },
        { "Georgian Standard Time", "Asia/Tbilisi" },
        { "Volgograd Standard Time", "Europe/Volgograd" },
        { "Caucasus Standard Time", "Asia/Yerevan" },
        { "Afghanistan Standard Time", "Asia/Kabul" },
        { "West Asia Standard Time", "Asia/Tashkent" },
        { "Ekaterinburg Standard Time", "Asia/Yekaterinburg" },
        { "Pakistan Standard Time", "Asia/Karachi" },
        { "Qyzylorda Standard Time", "Asia/Qyzylorda" },
        { "India Standard Time", "Asia/Calcutta" },
        { "Sri Lanka Standard Time", "Asia/Colombo" },
        { "Nepal Standard Time", "Asia/Katmandu" },
        { "Central Asia Standard Time", "Asia/Bishkek" },
        { "Bangladesh Standard Time", "Asia/Dhaka" },
        { "Omsk Standard Time", "Asia/Omsk" },
        { "Myanmar Standard Time", "Asia/Rangoon" },
        { "SE Asia Standard Time", "Asia/Bangkok" },
        { "Altai Standard Time", "Asia/Barnaul" },
        { "W. Mongolia Standard Time", "Asia/Hovd" },
        { "North Asia Standard Time", "Asia/Krasnoyarsk" },
        { "N. Central Asia Standard Time", "Asia/Novosibirsk" },
        { "Tomsk Standard Time", "Asia/Tomsk" },
        { "China Standard Time", "Asia/Shanghai" },
        { "North Asia East Standard Time", "Asia/Irkutsk" },
        { "Singapore Standard Time", "Asia/Singapore" },
        { "W. Australia Standard Time", "Australia/Perth" },
        { "Taipei Standard Time", "Asia/Taipei" },
        { "Ulaanbaatar Standard Time", "Asia/Ulaanbaatar" },
        { "Aus Central W. Standard Time", "Australia/Eucla" },
        { "Transbaikal Standard Time", "Asia/Chita" },
        { "Tokyo Standard Time", "Asia/Tokyo" },
        { "North Korea Standard Time", "Asia/Pyongyang" },
        { "Korea Standard Time", "Asia/Seoul" },
        { "Yakutsk Standard Time", "Asia/Yakutsk" },
        { "Cen. Australia Standard Time", "Australia/Adelaide" },
        { "AUS Central Standard Time", "Australia/Darwin" },
        { "E. Australia Standard Time", "Australia/Brisbane" },
        { "AUS Eastern Standard Time", "Australia/Sydney" },
        { "West Pacific Standard Time", "Pacific/Port_Moresby" },
        { "Tasmania Standard Time", "Australia/Hobart" },
        { "Vladivostok Standard Time", "Asia/Vladivostok" },
        { "Lord Howe Standard Time", "Australia/Lord_Howe" },
        { "Bougainville Standard Time", "Pacific/Bougainville" },
        { "Russia Time Zone 10", "Asia/Srednekolymsk" },
        { "Magadan Standard Time", "Asia/Magadan" },
        { "Norfolk Standard Time", "Pacific/Norfolk" },
        { "Sakhalin Standard Time", "Asia/Sakhalin" },
        { "Central Pacific Standard Time", "Pacific/Guadalcanal" },
        { "Russia Time Zone 11", "Asia/Kamchatka" },
        { "New Zealand Standard Time", "Pacific/Auckland" },
        { "UTC+12", "Etc/GMT-12" },
        { "Fiji Standard Time", "Pacific/Fiji" },
        { "Chatham Islands Standard Time", "Pacific/Chatham" },
        { "UTC+13", "Etc/GMT-13" },
        { "Tonga Standard Time", "Pacific/Tongatapu" },
        { "Samoa Standard Time", "Pacific/Apia" },
        { "Line Islands Standard Time", "Pacific/Kiritimati" },
    };
    DYNAMIC_TIME_ZONE_INFORMATION info;
    gchar *key;
    if (GetDynamicTimeZoneInformation(&info) == TIME_ZONE_ID_INVALID)
        return NULL;
    key = g_utf16_to_utf8((const gunichar2 *)info.TimeZoneKeyName, -1, NULL, NULL, NULL);
    if (!key) return NULL;
    for (gsize i = 0; i < G_N_ELEMENTS(zones); i++) {
        if (!strcmp(key, zones[i].windows)) {
            g_free(key);
            return g_strdup(zones[i].iana);
        }
    }
    g_warning("Gorizont timezone: unknown Windows zone '%s'", key);
    g_free(key);
    return NULL;
}
#endif
#endif
