/*
   Copyright (C) 2010 Red Hat, Inc.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, see <http://www.gnu.org/licenses/>.
*/
#include "config.h"

#include <glib.h>

#include "spice-client.h"

/**
 * spice_client_error_quark:
 *
 * Gets a #GQuark representing the string "spice-client-error-quark"
 *
 * Returns: the #GQuark representing the string.
 **/
GQuark spice_client_error_quark(void)
{
    return g_quark_from_static_string("spice-client-error-quark");
}
