#
# Gorizont SPICE-GTK tools
#

windows = import('windows')

spice_cmdline_sources = [
  'spice-cmdline.c',
  'spice-cmdline.h',
]

#
# gorizont-spicy-stats
#
executable(
  'gorizont-spicy-stats',
  sources : spice_cmdline_sources + [
    'spicy-stats.c',
  ],
  c_args : '-Wno-deprecated-declarations',
  install : true,
  dependencies : spice_client_glib_dep,
)

#
# gorizont-spicy-screenshot
#
executable(
  'gorizont-spicy-screenshot',
  sources : spice_cmdline_sources + [
    'spicy-screenshot.c',
  ],
  c_args : '-Wno-deprecated-declarations',
  install : true,
  dependencies : spice_client_glib_dep,
)

#
# gorizont-spicy
#
if spice_gtk_has_gtk
  spicy_sources = [
    'spicy.c',
    'spicy-connect.c',
    'spicy-connect.h',
    'spicy-theme.c',
    'spicy-theme.h',
  ]

  spicy_fonts_dir = get_option('datadir') / 'gorizont-spicy' / 'fonts'
  install_data(
    '../data/fonts/Montserrat-Medium.ttf',
    '../data/fonts/Montserrat-SemiBold.ttf',
    '../data/fonts/OFL.txt',
    install_dir : spicy_fonts_dir,
  )
  spicy_c_args = [
    '-Wno-deprecated-declarations',
    '-DSPICY_FONTS_DIR="@0@"'.format(get_option('prefix') / spicy_fonts_dir),
  ]
  spicy_deps = [spice_client_gtk_dep]

  # Windows loads the fonts by itself; elsewhere fontconfig does
  if host_machine.system() != 'windows'
    spicy_fontconfig = dependency('fontconfig', required : false)
    if spicy_fontconfig.found()
      spicy_deps += spicy_fontconfig
      spicy_c_args += '-DSPICY_HAVE_FONTCONFIG'
    endif
  endif

  if host_machine.system() == 'windows'
    message('Building gorizont-spicy.exe with embedded icon resource')

    spicy_icon = windows.compile_resources('spicy.rc')
    spicy_sources += spicy_icon
  endif

  executable(
    'gorizont-spicy',
    sources : spicy_sources + spice_cmdline_sources,
    c_args : spicy_c_args,
    gui_app : true,
    install : true,
    dependencies : spicy_deps,
  )
endif
