pod2man = find_program('pod2man')

if pod2man.found()
  custom_target(
    'gorizont-spice-client.1',
    output : 'gorizont-spice-client.1',
    input : 'spice-client.pod',
    install : true,
    install_dir : get_option('prefix') / get_option('mandir') / 'man1',
    build_by_default : true,
    command : [
      pod2man,
      '-c',
      'Gorizont SPICE-GTK Documentation',
      '-n',
      'gorizont-spice-client',
      '@INPUT@',
      '@OUTPUT@',
    ],
  )
endif
